'use strict';

angular.module('chooie', []);